function closePopup() {
    var popupOverlay = document.getElementById('popup-overlay');
    popupOverlay.style.display = 'none';
  }
  